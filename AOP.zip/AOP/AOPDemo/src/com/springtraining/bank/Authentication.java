package com.springtraining.bank;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Authentication {
	
		@Before("execution(* com.springtraining.bank.Account.*(..))")
		public void securityCheck(){
				System.out.println(".............Checking Security..");
		}
		
		@After("execution(* com.springtraining.bank.Account.*(..))")
		public void logging(){
				System.out.println(".............Logging happened..");
		}
		
		
}