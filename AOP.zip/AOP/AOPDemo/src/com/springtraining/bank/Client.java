
/**
 *
 */
package com.springtraining.bank;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * @ Mohammad Tufail Ahmed
 *
 */
public class Client {

	public static void main(String[] args) {
		ApplicationContext context
		= new AnnotationConfigApplicationContext(ApplicationConfig.class);
		
		Account account = context.getBean(Account.class);
		account.withdraw();
		account.deposit();
		account.pinChange();
		
	}
}