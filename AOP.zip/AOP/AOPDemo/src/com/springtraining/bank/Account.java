/**
 *
 */
package com.springtraining.bank;

/**
 * @ Mohammad Tufail Ahmed
 *
 */
public class Account {

	public void withdraw(){
		System.out.println("Withdrawing money..");
	}
	
	public void deposit(){
		System.out.println("Deposit money..");
	}
	
	public void pinChange(){
		System.out.println("Pin Change");
	}
}