package com.springtraining.bank;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * @ Mohammad Tufail Ahmed
 *
 */
@Configuration
@EnableAspectJAutoProxy
public class ApplicationConfig {

	@Bean
	public Account getAccount(){
		return new Account();
	}
	
	@Bean
	public Authentication geAuthentication(){
		return  new Authentication();
	}
}