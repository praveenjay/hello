package caching;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreData {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure("caching/hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction t = s.beginTransaction();
		
		Users users = new Users("Tufail","Ahmed");
		
		s.save(users);
		
		t.commit();
		System.out.println("Data Stored");


	}

}
