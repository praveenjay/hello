package com.init.springmvc;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class Initializer implements WebApplicationInitializer{

	@Override
	public void onStartup(ServletContext sc) throws ServletException {
		System.out.println("##########APPLICATION STARTED");
		AnnotationConfigWebApplicationContext context = 
				new AnnotationConfigWebApplicationContext();
		context.register(WebApp.class);
		
		context.setServletContext(sc);
		
		Dynamic d =sc.addServlet
		("dispatcher", new DispatcherServlet(context));
		d.addMapping("*.abc");
		d.setLoadOnStartup(1);
		
	}

}
