package com.maybank.inheritance;

public class RegularEmployee extends Employee {
	private int regulareEmployeeSalary;
	private int regulareEmployeeBonus;
	public int getRegulareEmployeeSalary() {
		return regulareEmployeeSalary;
	}
	public void setRegulareEmployeeSalary(int regulareEmployeeSalary) {
		this.regulareEmployeeSalary = regulareEmployeeSalary;
	}
	public int getRegulareEmployeeBonus() {
		return regulareEmployeeBonus;
	}
	public void setRegulareEmployeeBonus(int regulareEmployeeBonus) {
		this.regulareEmployeeBonus = regulareEmployeeBonus;
	}
	
}
