package com.maybank.inheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
			Configuration cfg = new Configuration().configure("com/maybank/inheritance/hello.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session s = sf.openSession();
			Transaction t = s.beginTransaction();
			
			Employee e1 = new Employee();
			e1.setEmployeeId(1);
			e1.setEmployeeName("Tufail");
			
			s.save(e1);
			
			RegularEmployee r1 = new RegularEmployee();
			r1.setEmployeeId(2);
			r1.setEmployeeName("Abhinav");
		
			r1.setRegulareEmployeeSalary(90000);
			r1.setRegulareEmployeeBonus(87000);
			
			s.save(r1);
			
		
			ContractEmployee c1 = new ContractEmployee();
			c1.setEmployeeId(3);
			c1.setEmployeeName("Suraj");
		
			c1.setPayPerHour(20);
			c1.setDuration("20");
			
			s.save(c1);
			
			t.commit();
			System.out.println("Data Stored");

	}

}
